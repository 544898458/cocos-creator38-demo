System.register(
  "external:emscripten/spine/spine.js.mem",
  [],
  function (_export, _context) {
    "use strict";
    return {
      setters: [],
      execute: function () {
        _export("default", "assets/spine.js.mem.bin");
      },
    };
  }
);
