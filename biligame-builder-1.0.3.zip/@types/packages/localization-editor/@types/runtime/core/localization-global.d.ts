export declare const pluginName = "Localization Editor";
export declare const mainName = "localization-editor";
export declare const runtimeBundleName = "l10n";
export declare const resourceListPath = "resource-list";
export declare const resourceBundlePath = "resource-bundle";
